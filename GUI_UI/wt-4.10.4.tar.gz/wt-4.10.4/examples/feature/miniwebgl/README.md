Mini-WebGL feature example
--------------------------

This shows a minimal (not really useful) usage of a WebGL widget.

How to run
----------

See the README in the parent directory.

What it illustrates
-------------------

- how to instantiate a `WGLWidget` widget.