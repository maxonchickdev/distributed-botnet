postAll feature example
-----------------------

This is an example that demonstrates how WServer::postAll can be used
to send a message to all active sessions.

How to run
----------

See the README in the parent directory.

What it illustrates
-------------------

- How WServer::postAll() can be used to send messages to all sessions.
- the user of the server push API
