WTemplate function example
--------------------------

This example illustrates how to create a custom function for WTemplate.
The example function allows you to automatically instantiate (and configure)
widgets from a template.

How to run
----------

See the README in the parent directory.

What it illustrates
-------------------

- how to extend WTemplate with new functionality