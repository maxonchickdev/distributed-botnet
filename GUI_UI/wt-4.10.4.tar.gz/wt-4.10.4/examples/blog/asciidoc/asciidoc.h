#ifndef ASCIIDOC_H_
#define ASCIIDOC_H_

namespace Wt {
  class WString;
}

extern Wt::WString asciidoc(const Wt::WString& src);

#endif // ASCIIDOC_H_
