File Treetable example
----------------------

This is an example that illustrates the `WTreeTable` API, and builds a
simple filesystem browser, listing the contents of the current working
directory.

How to run
----------

See the README in the parent directory.

What it illustrates
-------------------

- the use of the `WTreeTable` API